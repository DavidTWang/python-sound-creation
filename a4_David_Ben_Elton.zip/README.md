# python-sound-creation
Simple music creation in Python using the PyDub library

Requirements:
PyDub https://github.com/jiaaro/pydub

Pydub can be installed with ```pip install pydub```

This is a PoC using PyDub to create music
The current implementation of this program only creates a set song.
All the mixes and timings are hard-coded.


To run the program, simply run ```python creator.py```
